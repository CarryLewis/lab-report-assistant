# 项目支持文档

- [引用验证模块开发纲领](CITATION_VERIFICATION_CHARTER.md)：后续引用验证相关开发必须遵循的总体架构、证据要求、分期和验收约定；详细方案以此为准。

本目录将 `PROJECT_BRIEF.md` 的项目方向拆成后续产品设计、开发和试点可直接查阅的工作文档。开始新任务前，先阅读项目概要，再查阅与任务相对应的文档。

- [01 产品与网站体验](01_PRODUCT_AND_EXPERIENCE.md)：定义教师使用的网站、页面职责和关键交互。
- [02 教师工作流与运营](02_WORKFLOW_AND_OPERATIONS.md)：定义从准备课程到完成批改和持续改进的实际工作流程。
- [03 数据与 AI 分析](03_DATA_AND_AI_ANALYSIS.md)：定义资料准备、AI 输出、证据要求和质量控制。
- [04 试点与验证](04_PILOT_AND_VALIDATION.md)：定义试点如何开展、怎样收集教师反馈和判断是否扩大。
- [05 Turnitin 与教学平台接入](05_PLATFORM_INTEGRATION.md)：定义独立使用、LMS 接入和未来 Turnitin 工作流衔接的路径。
- [06 引用核验与外部文献检索](06_CITATION_VERIFICATION.md)：定义引文—条目—外部来源—内容证据链、接口边界、建设阶段和验收指标。

- [09 Navigation and domain model](09_NAVIGATION_AND_DOMAIN_MODEL.md): six teacher modules, page actions, entity relationships, invariants and current implementation boundaries.

## 使用原则

- 所有设计都应服务于教师辅助批改，而不是自动替代教师评分。
- AI 产生的建议必须能回到作业要求、rubric 和报告原文。
- 先完成一门课程的完整闭环，再扩大支持范围。
- 新功能若改变数据范围、教师责任或学校系统接入方式，先在相应文档中补充设计并确认。

